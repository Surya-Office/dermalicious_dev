<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-19 04:37:09 --> Query error: Duplicate entry 'UDC000000000000001' for key 'PRIMARY' - Invalid query: INSERT INTO `ms_customer` (`id_customer`, `nama_customer`, `telepon_1`, `telepon_2`) VALUES ('UDC000000000000001','Eva Agustina','6287786476176','6287786476176'), ('UDC000000000000002','Yeni Febriati','6281299075283','6281299075283'), ('UDC000000000000003','Fitri riana sari','6281326077757','6281326077757'), ('UDC000000000000004','Sarah Tuffahati','628119123444','628119123444'), ('UDC000000000000005','Widya Putri Adlina','6285311815687','6285311815687'), ('UDC000000000000006','Natasha Fernanda D. Manapa','6285718101820','6285718101820'), ('UDC000000000000007','Suwastini','6281314111092','6281314111092'), ('UDC000000000000008','Darling masiali','6282122219897','6282122219897'), ('UDC000000000000009','Dessy Fitria','6287778899898','6287778899898'), ('UDC000000000000010','Lizza Nadlira','6287808001515','6287808001515')
ERROR - 2023-05-19 08:12:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Customermaster C:\xampp\htdocs\dermalicious_dev\system\core\Loader.php 349
ERROR - 2023-05-19 08:13:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Customermaster C:\xampp\htdocs\dermalicious_dev\system\core\Loader.php 349
ERROR - 2023-05-19 08:13:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Customermaster C:\xampp\htdocs\dermalicious_dev\system\core\Loader.php 349
ERROR - 2023-05-19 08:13:20 --> Severity: error --> Exception: C:\xampp\htdocs\dermalicious_dev\application\models/master/Customermodel.php exists, but doesn't declare class Customermodel C:\xampp\htdocs\dermalicious_dev\system\core\Loader.php 341
ERROR - 2023-05-19 08:13:52 --> Severity: error --> Exception: C:\xampp\htdocs\dermalicious_dev\application\models/master/Customermodel.php exists, but doesn't declare class Customermodel C:\xampp\htdocs\dermalicious_dev\system\core\Loader.php 341
ERROR - 2023-05-19 08:14:13 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 08:15:39 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 08:15:42 --> Severity: error --> Exception: Call to undefined method CI_Session::role() C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 18
ERROR - 2023-05-19 08:16:47 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 9
ERROR - 2023-05-19 08:16:53 --> Severity: error --> Exception: Call to undefined method CI_Session::role() C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 21
ERROR - 2023-05-19 08:18:33 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 09:15:31 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 09:16:43 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 09:18:40 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 09:18:58 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 09:28:15 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 09:28:18 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 09:38:49 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 09:38:54 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 09:39:15 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 10:11:53 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 10:21:06 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 10:23:48 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 10:23:51 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 10:35:50 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 10:55:48 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 11:00:50 --> 404 Page Not Found: Transaksi/customer-detail-add.html
ERROR - 2023-05-19 11:00:51 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 11:34:51 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 11:51:30 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 12:16:22 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 12:16:23 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 12:17:09 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 12:20:44 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 12:21:07 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 12:23:23 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 12:28:05 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\css\style_create.php 5
ERROR - 2023-05-19 12:28:07 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\css\style_create.php 5
ERROR - 2023-05-19 12:28:58 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\css\style_create.php 5
ERROR - 2023-05-19 12:29:13 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 12:30:49 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-19 12:33:00 --> Query error: Unknown column 'nama_klinik' in 'field list' - Invalid query: SELECT `ms_klinik`.`id_klinik`, `nama_klinik`
FROM `tbl_klinik_perusahaan`
JOIN `ms_klinik` ON `ms_klinik`.`id_klinik` = `tbl_klinik_perusahaan`.`id_klinik`
WHERE `tbl_klinik_perusahaan`.`id_perusahaan` = '1'
ERROR - 2023-05-19 12:33:11 --> Query error: Unknown column 'nama_klinik' in 'field list' - Invalid query: SELECT `ms_klinik`.`id_klinik`, `nama_klinik`
FROM `tbl_klinik_perusahaan`
JOIN `ms_klinik` ON `ms_klinik`.`id_klinik` = `tbl_klinik_perusahaan`.`id_klinik`
WHERE `tbl_klinik_perusahaan`.`id_perusahaan` = '1'
ERROR - 2023-05-19 12:34:43 --> Query error: Unknown column 'ms_klinik.nama_klinik' in 'field list' - Invalid query: SELECT `ms_klinik`.`id_klinik`, `ms_klinik`.`nama_klinik`
FROM `tbl_klinik_perusahaan`
JOIN `ms_klinik` ON `ms_klinik`.`id_klinik` = `tbl_klinik_perusahaan`.`id_klinik`
WHERE `tbl_klinik_perusahaan`.`id_perusahaan` = '1'
ERROR - 2023-05-19 12:37:13 --> 404 Page Not Found: Transaksi/customer-detail-add.html
