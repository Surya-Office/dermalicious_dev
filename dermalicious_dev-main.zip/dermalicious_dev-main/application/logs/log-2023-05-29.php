<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-29 05:32:43 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-29 08:25:58 --> 404 Page Not Found: Transaksi/%3C
ERROR - 2023-05-29 08:57:35 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 70
ERROR - 2023-05-29 08:57:36 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 70
ERROR - 2023-05-29 09:01:24 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-29 09:43:23 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 83
ERROR - 2023-05-29 10:51:01 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-29 11:03:35 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-29 11:03:37 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-29 11:03:44 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-29 12:26:47 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-29 12:27:26 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-29 12:27:27 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-29 12:56:04 --> Severity: error --> Exception: Call to undefined method TransaksiModel::checkcust() C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 187
