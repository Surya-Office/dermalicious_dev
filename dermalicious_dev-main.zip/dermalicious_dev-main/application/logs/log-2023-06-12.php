<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-12 10:29:04 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 10:32:34 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 10:32:38 --> Query error: Column 'id_customer' cannot be null - Invalid query: INSERT INTO `ms_customer` (`id_customer`, `nama_customer`, `telepon_1`, `telepon_2`) VALUES (NULL, NULL, NULL, NULL)
ERROR - 2023-06-12 10:33:32 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 10:34:02 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 11:38:59 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 11:39:12 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 11:39:32 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 11:39:39 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 11:39:57 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 11:40:04 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 11:40:38 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 11:41:46 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 11:42:08 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 12:05:59 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 12:09:38 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 12:13:32 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 12:14:04 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 12:14:25 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 12:14:34 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 12:15:00 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 12:23:38 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 12:37:02 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 12:52:01 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' or ',' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_detail_trans.php 186
ERROR - 2023-06-12 14:26:17 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 14:50:21 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 14:50:34 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 14:51:33 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 14:52:30 --> Severity: error --> Exception: Too few arguments to function TransaksiModel::updateDataTrans(), 0 passed in C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php on line 492 and exactly 1 expected C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 351
ERROR - 2023-06-12 14:53:33 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 17:08:39 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 17:08:51 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-12 18:38:04 --> Severity: Notice --> Undefined index: nama_customer C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 358
ERROR - 2023-06-12 18:38:04 --> Severity: Notice --> Undefined index: telp_1 C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 359
ERROR - 2023-06-12 18:38:04 --> Severity: Notice --> Undefined index: telp_2 C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 360
ERROR - 2023-06-12 18:38:04 --> Severity: Notice --> Undefined index: id_customer C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 363
ERROR - 2023-06-12 18:38:04 --> Severity: Notice --> Undefined index: tgl_pembayaran C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 368
ERROR - 2023-06-12 18:38:04 --> Severity: Notice --> Undefined index: waktu_pembayaran C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 369
ERROR - 2023-06-12 18:38:04 --> Severity: Notice --> Undefined index: status_paket C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 371
ERROR - 2023-06-12 18:38:04 --> Severity: Notice --> Undefined index: id_customer C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 376
