<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-06 10:25:02 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 12 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 13 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:40 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:44 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:44 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:44 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:44 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:44 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:44 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:44 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:44 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:44 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:50:44 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 12 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 13 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:51:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 12 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 13 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:53:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 10:54:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 333
ERROR - 2023-06-06 11:12:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 334
ERROR - 2023-06-06 11:12:39 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 334
ERROR - 2023-06-06 11:13:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 334
ERROR - 2023-06-06 11:13:28 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 334
ERROR - 2023-06-06 11:13:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 334
ERROR - 2023-06-06 11:13:40 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 334
ERROR - 2023-06-06 11:14:34 --> Severity: error --> Exception: DatePeriod::__construct(): This constructor accepts either (DateTimeInterface, DateInterval, int) OR (DateTimeInterface, DateInterval, DateTime) OR (string) as arguments. C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 327
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:24:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:18 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:20 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:52 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:25:54 --> Severity: Notice --> Undefined index: date_holiday C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:27:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:27:19 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:27:19 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:27:19 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:27:19 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:27:19 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:27:19 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:27:19 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:27:19 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:27:19 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 12 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 13 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:07 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:09 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:09 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:09 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:09 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:09 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:09 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:09 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:09 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:28:09 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 12 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 13 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:23 --> Severity: Notice --> Undefined variable: sdate_end C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 342
ERROR - 2023-06-06 11:36:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:25 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:25 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:25 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:25 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:25 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:25 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:25 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:25 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:25 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:36:25 --> Severity: Notice --> Undefined variable: sdate_end C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 342
ERROR - 2023-06-06 11:37:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:18 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:18 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:18 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:18 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:18 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:18 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:18 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:18 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:18 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:18 --> Severity: Notice --> Undefined variable: sdate_end C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 342
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 12 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 13 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:44 --> Severity: Notice --> Undefined variable: sdate_end C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 342
ERROR - 2023-06-06 11:37:47 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:47 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:47 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:47 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:47 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:47 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:47 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:47 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:47 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:47 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 337
ERROR - 2023-06-06 11:37:47 --> Severity: Notice --> Undefined variable: sdate_end C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 342
ERROR - 2023-06-06 11:44:00 --> Severity: Notice --> Trying to get property 'date_holiday' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 320
ERROR - 2023-06-06 11:44:37 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 11:45:26 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:45:26 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:45:26 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:45:26 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:45:26 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:45:26 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:45:26 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:45:26 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:45:26 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:45:26 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:46:13 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:46:13 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:46:13 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:46:13 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:46:13 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:46:13 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:46:13 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:46:13 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:46:13 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:46:13 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:12 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:12 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:12 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:12 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:12 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:12 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:12 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:12 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:12 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:12 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:34 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:34 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:34 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:34 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:34 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:34 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:34 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:34 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:34 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:34 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:48 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:48 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:48 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:48 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:48 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:48 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:48 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:48 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:48 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:48:48 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:49:52 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:49:52 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:49:52 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:49:52 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:49:52 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:49:52 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:49:52 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:49:52 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:49:52 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:49:52 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:50:08 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:50:08 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:50:08 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:50:08 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:50:08 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:50:08 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:50:08 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:50:08 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:50:08 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 11:50:08 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 338
ERROR - 2023-06-06 12:10:18 --> Severity: Notice --> Undefined variable: daysRequired C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 348
ERROR - 2023-06-06 12:10:22 --> Severity: Notice --> Undefined variable: daysRequired C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 348
ERROR - 2023-06-06 12:11:19 --> Severity: Notice --> Undefined variable: isExcluded C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 353
ERROR - 2023-06-06 12:11:19 --> Severity: Notice --> Undefined variable: isExcluded C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 353
ERROR - 2023-06-06 12:11:19 --> Severity: Notice --> Undefined variable: isExcluded C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 353
ERROR - 2023-06-06 12:11:19 --> Severity: Notice --> Undefined variable: isExcluded C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 353
ERROR - 2023-06-06 12:11:19 --> Severity: Notice --> Undefined variable: isExcluded C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 353
ERROR - 2023-06-06 12:11:19 --> Severity: Notice --> Undefined variable: isExcluded C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 353
ERROR - 2023-06-06 12:11:19 --> Severity: Notice --> Undefined variable: isExcluded C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 353
ERROR - 2023-06-06 12:11:19 --> Severity: Notice --> Undefined variable: isExcluded C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 353
ERROR - 2023-06-06 12:11:19 --> Severity: Notice --> Undefined variable: isExcluded C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 353
ERROR - 2023-06-06 12:11:19 --> Severity: Notice --> Undefined variable: isExcluded C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 353
ERROR - 2023-06-06 12:11:19 --> Severity: Notice --> Undefined variable: isExcluded C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 353
ERROR - 2023-06-06 12:11:19 --> Severity: Notice --> Undefined variable: isExcluded C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 353
ERROR - 2023-06-06 12:11:19 --> Severity: Notice --> Undefined variable: isExcluded C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 353
ERROR - 2023-06-06 12:12:21 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:21 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:21 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:21 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:21 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:21 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:21 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:21 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:21 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:21 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:21 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:21 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:21 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:23 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:23 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:23 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:23 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:23 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:23 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:23 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:23 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:23 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:23 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:23 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:23 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:12:23 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:14:06 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:14:06 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:14:06 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:14:06 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:14:06 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:14:06 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:14:06 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:14:06 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:14:06 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:14:06 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:14:06 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:14:06 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:14:06 --> Severity: Notice --> Undefined property: DateTimeImmutable::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 354
ERROR - 2023-06-06 12:18:59 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:18:59 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:18:59 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:18:59 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:18:59 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:18:59 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:18:59 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:18:59 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:18:59 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:18:59 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:19:28 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:19:28 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:19:28 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:19:28 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:19:28 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:19:28 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:19:28 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:19:28 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:19:28 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:19:28 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:20:38 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:20:38 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:20:38 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:20:38 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:20:38 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:20:38 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:20:38 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:20:38 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:20:38 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:20:38 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:21:24 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:21:24 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:21:24 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:21:24 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:21:24 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:21:24 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:21:24 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:21:24 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:21:24 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:21:24 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:04 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:04 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:04 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:04 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:04 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:04 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:04 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:04 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:04 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:04 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:15 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:15 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:15 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:15 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:15 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:15 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:15 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:15 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:15 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:22:15 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:29:40 --> Severity: Warning --> DateTime::diff() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 327
ERROR - 2023-06-06 12:29:40 --> Severity: Notice --> Trying to get property 'days' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 330
ERROR - 2023-06-06 12:40:32 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 350
ERROR - 2023-06-06 12:42:22 --> Severity: Warning --> in_array() expects at least 2 parameters, 1 given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 347
ERROR - 2023-06-06 12:42:25 --> Severity: Warning --> in_array() expects at least 2 parameters, 1 given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 347
ERROR - 2023-06-06 12:44:35 --> Severity: error --> Exception: Cannot use object of type DatePeriod as array C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 335
ERROR - 2023-06-06 12:44:55 --> Severity: error --> Exception: Cannot use object of type DateTime as array C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 345
ERROR - 2023-06-06 12:45:16 --> Severity: Notice --> Undefined property: DatePeriod::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 344
ERROR - 2023-06-06 12:45:18 --> Severity: Notice --> Undefined property: DatePeriod::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 344
ERROR - 2023-06-06 12:45:29 --> Severity: Notice --> Undefined property: DatePeriod::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 345
ERROR - 2023-06-06 12:45:41 --> Severity: Notice --> Undefined property: DateTime::$date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 345
ERROR - 2023-06-06 12:56:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:56:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:56:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:56:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:56:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:56:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:56:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:56:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:56:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:56:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:56:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:56:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:58:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:58:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:58:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:58:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:58:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:58:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:58:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:58:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:58:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:58:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:58:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 12:58:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 339
ERROR - 2023-06-06 16:34:22 --> Severity: Notice --> Undefined index: start_date_paket C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 232
ERROR - 2023-06-06 16:34:22 --> Severity: Notice --> Undefined index: end_date_paket C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 233
ERROR - 2023-06-06 18:25:26 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 39
ERROR - 2023-06-06 18:25:26 --> Severity: Notice --> Undefined variable: detail_paket C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 46
ERROR - 2023-06-06 18:25:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 40
ERROR - 2023-06-06 18:26:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 40
ERROR - 2023-06-06 18:26:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 40
ERROR - 2023-06-06 18:29:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 41
ERROR - 2023-06-06 18:30:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 41
ERROR - 2023-06-06 18:30:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 41
