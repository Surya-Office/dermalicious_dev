<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-09 11:05:28 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 12:06:50 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 12:13:19 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 12:13:31 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 12:14:10 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 12:20:10 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 12:20:11 --> Query error: Unknown column 'tbl_transaksi_detail.tgl_pengiriman' in 'group statement' - Invalid query: SELECT `tbl_transaksi_pengiriman`.`tgl_pengiriman`, `jenis_paket`, `jml_pack_dikirim`
FROM `tbl_transaksi_pengiriman`
JOIN `tbl_transaksi_detail` ON `tbl_transaksi_detail`.`id_transaksi_detail` = `tbl_transaksi_pengiriman`.`id_transaksi_detail`
GROUP BY `tbl_transaksi_detail`.`tgl_pengiriman`
 LIMIT 10
ERROR - 2023-06-09 12:21:45 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 12:28:10 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 12:28:43 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 14:20:16 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 14:27:34 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 14:32:36 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 14:33:42 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 14:34:01 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 14:34:23 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:06:29 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:14:00 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:05 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:16:06 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> Severity: Warning --> Illegal string offset 'id_user' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:00 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:17:09 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 49
ERROR - 2023-06-09 15:19:39 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:28:48 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:32:29 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:33:07 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:40:31 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:41:30 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:41:47 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:42:29 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:45:43 --> Severity: Notice --> Undefined property: stdClass::$tgl_trans C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 180
ERROR - 2023-06-09 15:45:44 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:45:59 --> Severity: Notice --> Undefined property: stdClass::$tgl_transakasi C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 180
ERROR - 2023-06-09 15:45:59 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:46:13 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:48:21 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:58:33 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 231
ERROR - 2023-06-09 15:58:33 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 15:58:56 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 231
ERROR - 2023-06-09 15:58:56 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 16:05:15 --> Severity: Notice --> Undefined property: stdClass::$status_paiment C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 231
ERROR - 2023-06-09 16:05:15 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 16:05:29 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 16:15:15 --> Severity: Notice --> Undefined index: rowid C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 302
ERROR - 2023-06-09 16:15:15 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 16:15:37 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 16:47:17 --> Severity: Notice --> Undefined index: id-transaksi C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_trans.php 319
ERROR - 2023-06-09 16:47:17 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 16:47:33 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 16:47:35 --> 404 Page Not Found: Transaksi/editdetailtransaksi
ERROR - 2023-06-09 18:07:07 --> Severity: Notice --> Undefined variable: start_date_periode C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_detail_trans.php 149
ERROR - 2023-06-09 18:32:50 --> Severity: Notice --> Undefined variable: start_date_periode C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_detail_trans.php 149
ERROR - 2023-06-09 18:34:57 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:35:10 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:35:55 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:36:44 --> Severity: Notice --> Undefined variable: start_date_periode C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_detail_trans.php 149
ERROR - 2023-06-09 18:36:48 --> Severity: Notice --> Undefined variable: start_date_periode C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_detail_trans.php 149
ERROR - 2023-06-09 18:37:15 --> Severity: Notice --> Undefined variable: start_date_periode C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\edit_detail_trans.php 149
ERROR - 2023-06-09 18:40:28 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:40:45 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:40:49 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:41:41 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:42:08 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:43:19 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:43:29 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:43:49 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:44:31 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:45:09 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:45:25 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:48:01 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-09 18:48:36 --> 404 Page Not Found: Asstes/dist
