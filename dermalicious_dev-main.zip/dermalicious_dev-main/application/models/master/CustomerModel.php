<?php

class CusromerModel extends CI_Model
{
    
}
