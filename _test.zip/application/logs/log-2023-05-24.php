<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-24 05:32:18 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-24 10:24:25 --> 404 Page Not Found: Transaksi/customer-detail.html
