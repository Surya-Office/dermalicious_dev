<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-17 05:29:54 --> 404 Page Not Found: Dashboard/dist
ERROR - 2023-05-17 05:30:41 --> 404 Page Not Found: Dashboard/dist
ERROR - 2023-05-17 05:39:20 --> 404 Page Not Found: Dashboard/plugins
ERROR - 2023-05-17 05:39:20 --> 404 Page Not Found: Dashboard/plugins
ERROR - 2023-05-17 05:39:26 --> 404 Page Not Found: Dashboard/plugins
ERROR - 2023-05-17 05:39:26 --> 404 Page Not Found: Dashboard/plugins
ERROR - 2023-05-17 05:41:24 --> 404 Page Not Found: Dashboard/dist
ERROR - 2023-05-17 05:41:24 --> 404 Page Not Found: Dashboard/plugins
ERROR - 2023-05-17 05:41:24 --> 404 Page Not Found: Dashboard/plugins
ERROR - 2023-05-17 05:42:15 --> 404 Page Not Found: Dashboard/plugins
ERROR - 2023-05-17 05:42:15 --> 404 Page Not Found: Dashboard/plugins
ERROR - 2023-05-17 05:42:52 --> 404 Page Not Found: Dashboard/assets
ERROR - 2023-05-17 05:42:52 --> 404 Page Not Found: Dashboard/assets
ERROR - 2023-05-17 06:05:00 --> 404 Page Not Found: Dashboard/customer-transaction.html
ERROR - 2023-05-17 06:42:10 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\system\database\DB_query_builder.php 2443
ERROR - 2023-05-17 06:45:20 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\system\database\DB_query_builder.php 2443
ERROR - 2023-05-17 06:46:14 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\system\database\DB_query_builder.php 2443
ERROR - 2023-05-17 06:51:13 --> Severity: error --> Exception: Cannot use object of type mysqli as array C:\xampp\htdocs\dermalicious_dev\application\controllers\Login.php 46
ERROR - 2023-05-17 07:06:23 --> 404 Page Not Found: Dashboard/customer-transaction.html
ERROR - 2023-05-17 07:12:02 --> 404 Page Not Found: Dashboard/customer-transaction.html
ERROR - 2023-05-17 07:12:11 --> 404 Page Not Found: Dist/css
ERROR - 2023-05-17 07:12:11 --> 404 Page Not Found: Dist/css
ERROR - 2023-05-17 07:12:11 --> 404 Page Not Found: Dist/img
ERROR - 2023-05-17 07:12:14 --> 404 Page Not Found: Dist/css
ERROR - 2023-05-17 07:12:14 --> 404 Page Not Found: Dist/css
ERROR - 2023-05-17 07:12:51 --> 404 Page Not Found: Dist/img
ERROR - 2023-05-17 07:13:32 --> 404 Page Not Found: Dist/img
ERROR - 2023-05-17 07:13:58 --> 404 Page Not Found: Dist/img
ERROR - 2023-05-17 07:19:33 --> 404 Page Not Found: Dist/img
ERROR - 2023-05-17 07:21:21 --> 404 Page Not Found: Dist/img
ERROR - 2023-05-17 07:21:39 --> 404 Page Not Found: Dist/img
ERROR - 2023-05-17 07:22:36 --> 404 Page Not Found: Dist/img
ERROR - 2023-05-17 07:26:36 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-17 07:26:36 --> 404 Page Not Found: Dist/js
ERROR - 2023-05-17 07:26:36 --> 404 Page Not Found: Dist/img
ERROR - 2023-05-17 07:26:36 --> 404 Page Not Found: Dist/js
ERROR - 2023-05-17 07:27:18 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-17 07:27:18 --> 404 Page Not Found: Dist/img
ERROR - 2023-05-17 07:29:24 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-17 07:29:25 --> 404 Page Not Found: Dist/img
ERROR - 2023-05-17 07:30:57 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-17 11:08:29 --> 404 Page Not Found: Customer/index
ERROR - 2023-05-17 11:09:07 --> Severity: Warning --> json_decode() expects parameter 1 to be string, object given C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 17
ERROR - 2023-05-17 11:21:53 --> Severity: Warning --> Illegal string offset 'CUSTOMER_ID' C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 18
ERROR - 2023-05-17 11:22:02 --> Severity: Notice --> Trying to get property 'CUSTOMER_ID' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 18
ERROR - 2023-05-17 11:26:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 18
ERROR - 2023-05-17 11:27:22 --> Severity: Notice --> Trying to get property 'CUSTOMER_ID' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 17
ERROR - 2023-05-17 11:36:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 18
ERROR - 2023-05-17 11:38:40 --> Severity: Notice --> Trying to get property 'CUSTOMER_ID' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:38:40 --> Severity: Notice --> Trying to get property 'CUSTOMER_ID' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:38:40 --> Severity: Notice --> Trying to get property 'CUSTOMER_ID' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:38:40 --> Severity: Notice --> Trying to get property 'CUSTOMER_ID' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:38:40 --> Severity: Notice --> Trying to get property 'CUSTOMER_ID' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:04 --> Severity: Warning --> Illegal string offset 'CUSTOMER_ID' C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:04 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:04 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:04 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:04 --> Severity: Notice --> Undefined index: CUSTOMER_ID C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:05 --> Severity: Warning --> Illegal string offset 'CUSTOMER_ID' C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:05 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:05 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:05 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:05 --> Severity: Notice --> Undefined index: CUSTOMER_ID C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:05 --> Severity: Warning --> Illegal string offset 'CUSTOMER_ID' C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:05 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:05 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:05 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:39:05 --> Severity: Notice --> Undefined index: CUSTOMER_ID C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:48:05 --> Severity: error --> Exception: Call to undefined method stdClass::data() C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 16
ERROR - 2023-05-17 11:50:19 --> Severity: Warning --> Illegal string offset 'data' C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:50:19 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:50:19 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:50:19 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:50:19 --> Severity: Notice --> Undefined index: data C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:50:31 --> Severity: Notice --> Trying to get property 'CUSTOMER_ID' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:50:31 --> Severity: Notice --> Trying to get property 'CUSTOMER_ID' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:50:31 --> Severity: Notice --> Trying to get property 'CUSTOMER_ID' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:50:31 --> Severity: Notice --> Trying to get property 'CUSTOMER_ID' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 11:50:31 --> Severity: Notice --> Trying to get property 'CUSTOMER_ID' of non-object C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 21
ERROR - 2023-05-17 12:06:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 22
ERROR - 2023-05-17 12:06:11 --> Severity: Notice --> Undefined variable: data_cust C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 18
ERROR - 2023-05-17 12:06:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\master\customer\front.php 18
ERROR - 2023-05-17 12:07:57 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 20
ERROR - 2023-05-17 12:08:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 18
ERROR - 2023-05-17 12:08:06 --> Severity: Notice --> Trying to get property 'data' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 18
ERROR - 2023-05-17 12:08:34 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 20
ERROR - 2023-05-17 12:12:45 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 20
ERROR - 2023-05-17 12:13:23 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 21
ERROR - 2023-05-17 12:13:42 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 21
ERROR - 2023-05-17 12:14:14 --> Severity: Notice --> Trying to get property 'CUSTOMER_ID' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 19
ERROR - 2023-05-17 12:14:26 --> Severity: Notice --> Trying to get property 'CUSTOMER_ID' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 19
ERROR - 2023-05-17 12:46:22 --> Severity: Notice --> Trying to get property 'data' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 18
ERROR - 2023-05-17 12:46:22 --> Severity: Notice --> Trying to get property 'total_page' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 19
ERROR - 2023-05-17 12:49:48 --> Severity: Notice --> Trying to get property 'data' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 18
ERROR - 2023-05-17 12:49:48 --> Severity: Notice --> Trying to get property 'total_page' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\master\Customer.php 19
