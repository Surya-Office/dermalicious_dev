<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-14 05:35:25 --> 404 Page Not Found: Public/home
ERROR - 2023-06-14 05:35:26 --> 404 Page Not Found: Static/admin
