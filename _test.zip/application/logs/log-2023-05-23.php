<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-23 04:26:40 --> Severity: Notice --> Undefined variable: your_value C:\xampp\htdocs\dermalicious_dev\application\controllers\Login.php 74
ERROR - 2023-05-23 04:26:48 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-23 05:01:49 --> Query error: Unknown column 'ec_cities.dis_id' in 'on clause' - Invalid query: SELECT `ec_subdistricts`.`subdis_id`, `subdis_name`
FROM `ec_subdistricts`
JOIN `ec_districts` ON `ec_cities`.`dis_id` = `ec_districts`.`dis_id`
WHERE `ec_districts`.`dis_id` = '1919'
ERROR - 2023-05-23 05:11:21 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\dermalicious_dev\system\database\DB_query_builder.php 2443
ERROR - 2023-05-23 05:11:21 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `ec_postalcode`.`subdis_id`, `subdis_name`
FROM `ec_postalcode`
JOIN `ec_subdistricts` ON `ec_subdistricts`.`subdis_id` = `ec_postalcode`.`subdis_id`
WHERE `ec_postalcode`.`subdis_id` = Array
ERROR - 2023-05-23 05:36:23 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 114
ERROR - 2023-05-23 05:38:28 --> Severity: Notice --> Undefined variable: opt C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 118
ERROR - 2023-05-23 05:38:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 118
ERROR - 2023-05-23 05:40:19 --> Severity: Notice --> Trying to get property 'postal_code' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 118
ERROR - 2023-05-23 05:41:03 --> Severity: Notice --> Trying to get property 'postal_code' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 113
ERROR - 2023-05-23 05:41:34 --> Severity: Notice --> Undefined index: postal_code C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 113
ERROR - 2023-05-23 06:13:08 --> Severity: Warning --> Illegal string offset 'city_id' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:13:08 --> Severity: Warning --> Illegal string offset 'city_name' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:13:08 --> Severity: Warning --> Illegal string offset 'city_id' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:13:08 --> Severity: Warning --> Illegal string offset 'city_name' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:15:29 --> Severity: Warning --> Illegal string offset 'city_id' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:15:29 --> Severity: Warning --> Illegal string offset 'city_name' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:15:29 --> Severity: Warning --> Illegal string offset 'city_id' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:15:29 --> Severity: Warning --> Illegal string offset 'city_name' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:23:51 --> Severity: Warning --> Illegal string offset 'city_id' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 215
ERROR - 2023-05-23 06:24:37 --> Severity: Warning --> Illegal string offset 'city_id' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 215
ERROR - 2023-05-23 06:24:45 --> Severity: Warning --> Illegal string offset 'city_id' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 215
ERROR - 2023-05-23 06:24:54 --> Severity: Warning --> Illegal string offset 'city_id' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 215
ERROR - 2023-05-23 06:25:27 --> Severity: Warning --> Illegal string offset 'city_id' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:25:27 --> Severity: Warning --> Illegal string offset 'city_name' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:25:27 --> Severity: Warning --> Illegal string offset 'city_id' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:25:27 --> Severity: Warning --> Illegal string offset 'city_name' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:30:31 --> Severity: Warning --> Illegal string offset 'city_id' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:30:31 --> Severity: Warning --> Illegal string offset 'city_name' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:30:31 --> Severity: Warning --> Illegal string offset 'city_id' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
ERROR - 2023-05-23 06:30:32 --> Severity: Warning --> Illegal string offset 'city_name' C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\menu_paket.php 216
