<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-13 10:56:50 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-13 11:01:56 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-13 11:09:02 --> Severity: Notice --> Undefined index: start_date_paket C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 436
ERROR - 2023-06-13 11:09:02 --> Severity: Notice --> Undefined index: end_date_paket C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 437
ERROR - 2023-06-13 11:09:02 --> Severity: Notice --> Undefined index: km_1 C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 450
ERROR - 2023-06-13 11:09:02 --> Severity: Notice --> Undefined index: km_2 C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 458
ERROR - 2023-06-13 11:09:02 --> Severity: Notice --> Undefined index: km_3 C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 465
ERROR - 2023-06-13 11:09:02 --> Severity: Notice --> Undefined index: jadwal_pengiriman C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 468
ERROR - 2023-06-13 11:09:02 --> Query error: Unknown column 'id_detail_transaksi' in 'where clause' - Invalid query: UPDATE `tbl_transaksi_detail` SET `waktu_paket` = 'dinner', `start_date_periode_paket` = '1970-01-01', `end_date_periode_paket` = '1970-01-01', `deskripsi` = '', `kategori_paket` = 'Paket Healty A', `jenis_paket` = 'Healthy', `qty_pemesanan` = '24', `detail_paket` = 'Healthy - lunch', `periode_paket` = '1 Bulan', `alamat_1` = 'dermaster mangga besar', `kelurahan_1` = NULL, `kecamatan_1` = NULL, `kota_1` = NULL, `maps_1` = 'https://maps.google.com/maps?q=dermaster%20mangga%20besar&output=embed', `km_1` = 0, `alamat_lengkap_1` = 'dermaster mangga besar', `alamat_2` = 'derma express utan kayu', `kelurahan_2` = NULL, `kecamatan_2` = NULL, `kota_2` = NULL, `maps_2` = 'https://maps.google.com/maps?q=derma%20express%20utan%20kayu&output=embed', `alamat_lengkap_2` = 'derma express utan kayu', `km_2` = 0, `alamat_3` = 'dermaster head office ', `kelurahan_3` = NULL, `kecamatan_3` = NULL, `kota_3` = NULL, `maps_3` = 'https://maps.google.com/maps?q=dermaster%20head%20office%20&output=embed', `alamat_lengkap_3` = 'dermaster head office ', `km_3` = 0, `note_pengiriman_3` = 'titip pada security', `riwayat_alergi` = '', `jadwal_pengiriman` = NULL
WHERE `id_transaksi` = '2'
AND `id_detail_transaksi` = '2'
ERROR - 2023-06-13 11:09:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\dermalicious_dev\system\core\Exceptions.php:272) C:\xampp\htdocs\dermalicious_dev\system\core\Common.php 571
ERROR - 2023-06-13 11:10:04 --> Severity: Notice --> Undefined index: km_1 C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 450
ERROR - 2023-06-13 11:10:04 --> Severity: Notice --> Undefined index: km_2 C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 458
ERROR - 2023-06-13 11:10:04 --> Severity: Notice --> Undefined index: km_3 C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 465
ERROR - 2023-06-13 11:10:04 --> Severity: Notice --> Undefined index: jadwal_pengiriman C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 468
ERROR - 2023-06-13 11:10:04 --> Query error: Unknown column 'id_detail_transaksi' in 'where clause' - Invalid query: UPDATE `tbl_transaksi_detail` SET `waktu_paket` = 'dinner', `start_date_periode_paket` = '2023-06-12', `end_date_periode_paket` = '2023-07-08', `deskripsi` = '', `kategori_paket` = 'Paket Healty A', `jenis_paket` = 'Healthy', `qty_pemesanan` = '24', `detail_paket` = 'Healthy - lunch', `periode_paket` = '1 Bulan', `alamat_1` = 'dermaster mangga besar', `kelurahan_1` = NULL, `kecamatan_1` = NULL, `kota_1` = NULL, `maps_1` = 'https://maps.google.com/maps?q=dermaster%20mangga%20besar&output=embed', `km_1` = 0, `alamat_lengkap_1` = 'dermaster mangga besar', `alamat_2` = 'derma express utan kayu', `kelurahan_2` = NULL, `kecamatan_2` = NULL, `kota_2` = NULL, `maps_2` = 'https://maps.google.com/maps?q=derma%20express%20utan%20kayu&output=embed', `alamat_lengkap_2` = 'derma express utan kayu', `km_2` = 0, `alamat_3` = 'dermaster head office ', `kelurahan_3` = NULL, `kecamatan_3` = NULL, `kota_3` = NULL, `maps_3` = 'https://maps.google.com/maps?q=dermaster%20head%20office%20&output=embed', `alamat_lengkap_3` = 'dermaster head office ', `km_3` = 0, `note_pengiriman_3` = 'titip pada security', `riwayat_alergi` = '', `jadwal_pengiriman` = NULL
WHERE `id_transaksi` = '2'
AND `id_detail_transaksi` = '2'
ERROR - 2023-06-13 11:15:07 --> Severity: Notice --> Undefined variable: km_1 C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 451
ERROR - 2023-06-13 11:15:07 --> Severity: Notice --> Undefined variable: km_2 C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 459
ERROR - 2023-06-13 11:15:07 --> Severity: Notice --> Undefined variable: km_3 C:\xampp\htdocs\dermalicious_dev\application\models\TransaksiModel.php 466
ERROR - 2023-06-13 11:18:11 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-13 17:32:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/u105648188/domains/ayrusp.com/public_html/test/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2023-06-13 17:32:05 --> Unable to connect to the database
ERROR - 2023-06-13 17:35:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/u105648188/domains/ayrusp.com/public_html/test/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2023-06-13 17:35:38 --> Unable to connect to the database
ERROR - 2023-06-13 17:36:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/u105648188/domains/ayrusp.com/public_html/test/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2023-06-13 17:36:00 --> Unable to connect to the database
ERROR - 2023-06-13 17:36:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'user'@'localhost' (using password: YES) /home/u105648188/domains/ayrusp.com/public_html/test/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2023-06-13 17:36:57 --> Unable to connect to the database
ERROR - 2023-06-13 17:38:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Aksesmodel /home/u105648188/domains/ayrusp.com/public_html/test/system/core/Loader.php 349
ERROR - 2023-06-13 17:41:30 --> 404 Page Not Found: Dashboard/index.html
ERROR - 2023-06-13 17:41:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Aksesmodel /home/u105648188/domains/ayrusp.com/public_html/test/system/core/Loader.php 349
ERROR - 2023-06-13 17:42:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaksimodel /home/u105648188/domains/ayrusp.com/public_html/test/system/core/Loader.php 349
ERROR - 2023-06-13 17:42:22 --> Severity: Warning --> Undefined property: Transaksi::$transaksimodel /home/u105648188/domains/ayrusp.com/public_html/test/application/controllers/Transaksi.php 359
ERROR - 2023-06-13 17:42:22 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/u105648188/domains/ayrusp.com/public_html/test/application/controllers/Transaksi.php 359
ERROR - 2023-06-13 17:42:47 --> Severity: Warning --> Undefined property: Transaksi::$transaksimodel /home/u105648188/domains/ayrusp.com/public_html/test/application/controllers/Transaksi.php 359
ERROR - 2023-06-13 17:42:47 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/u105648188/domains/ayrusp.com/public_html/test/application/controllers/Transaksi.php 359
ERROR - 2023-06-13 17:45:02 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-13 17:50:55 --> Severity: Warning --> Attempt to read property "postal_code" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/controllers/Transaksi.php 177
ERROR - 2023-06-13 17:51:04 --> Severity: Warning --> Attempt to read property "postal_code" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/controllers/Transaksi.php 177
ERROR - 2023-06-13 17:53:52 --> Severity: Warning --> Attempt to read property "postal_code" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/controllers/Transaksi.php 177
ERROR - 2023-06-13 18:07:16 --> Severity: Warning --> Undefined property: Transaksi::$transaksimodel /home/u105648188/domains/ayrusp.com/public_html/test/application/controllers/Transaksi.php 210
ERROR - 2023-06-13 18:07:16 --> Severity: error --> Exception: Call to a member function getKM() on null /home/u105648188/domains/ayrusp.com/public_html/test/application/controllers/Transaksi.php 210
ERROR - 2023-06-13 18:18:22 --> Severity: Warning --> Undefined property: Transaksi::$transaksimodel /home/u105648188/domains/ayrusp.com/public_html/test/application/controllers/Transaksi.php 209
ERROR - 2023-06-13 18:18:22 --> Severity: error --> Exception: Call to a member function getKM() on null /home/u105648188/domains/ayrusp.com/public_html/test/application/controllers/Transaksi.php 209
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "id_user" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 48
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "status_paket" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 54
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "status_paket" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 62
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "id_transaksi" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 68
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "nama" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 77
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "nama_klinik" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 83
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "id_customer" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 92
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "nama_customer" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 98
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "telepon_1" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 107
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "telepon_2" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 114
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "tgl_transaksi" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 124
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "paid_date" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 133
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "status_payment" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 142
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "status_veryfied" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 185
ERROR - 2023-06-13 18:33:59 --> Severity: Warning --> Attempt to read property "notes" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 204
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "id_user" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 48
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "status_paket" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 54
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "status_paket" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 62
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "id_transaksi" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 68
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "nama" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 77
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "nama_klinik" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 83
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "id_customer" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 92
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "nama_customer" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 98
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "telepon_1" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 107
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "telepon_2" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 114
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "tgl_transaksi" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 124
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "paid_date" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 133
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "status_payment" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 142
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "status_veryfied" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 185
ERROR - 2023-06-13 18:34:08 --> Severity: Warning --> Attempt to read property "notes" on null /home/u105648188/domains/ayrusp.com/public_html/test/application/views/transaksi/detail_trans.php 204
ERROR - 2023-06-13 18:34:35 --> 404 Page Not Found: Timetable/index
ERROR - 2023-06-13 18:34:42 --> 404 Page Not Found: Dashboard/index.html
ERROR - 2023-06-13 18:34:44 --> 404 Page Not Found: Dashboard/index.html
ERROR - 2023-06-13 18:34:51 --> 404 Page Not Found: Timetable/index
ERROR - 2023-06-13 18:38:57 --> 404 Page Not Found: Asstes/dist
