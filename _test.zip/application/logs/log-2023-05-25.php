<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-25 05:07:38 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-25 07:03:59 --> Severity: error --> Exception: Call to undefined method CI_Cart::data() C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 127
ERROR - 2023-05-25 08:49:18 --> Severity: Notice --> Undefined index: map_1 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 141
ERROR - 2023-05-25 08:49:18 --> Severity: Notice --> Undefined index: map_2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 148
ERROR - 2023-05-25 08:49:18 --> Severity: Notice --> Undefined index: map_3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 155
ERROR - 2023-05-25 08:49:53 --> Severity: Notice --> Undefined index: maps_1 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 141
ERROR - 2023-05-25 08:49:53 --> Severity: Notice --> Undefined index: maps_2 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 148
ERROR - 2023-05-25 08:49:53 --> Severity: Notice --> Undefined index: maps_3 C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 155
ERROR - 2023-05-25 09:26:55 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2023-05-25 09:26:57 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2023-05-25 09:26:58 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2023-05-25 10:12:56 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2023-05-25 10:13:04 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2023-05-25 10:14:42 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2023-05-25 10:24:48 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-25 10:35:44 --> Severity: error --> Exception: Call to undefined method CI_Cart::content() C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 32
ERROR - 2023-05-25 11:01:49 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-25 11:01:54 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-25 11:04:02 --> Query error: Unknown column 'id_jenis' in 'where clause' - Invalid query: SELECT `jenis_paket`
FROM `ms_jenis_paket`
WHERE `id_jenis` = '2'
