<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-26 04:49:35 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-26 08:58:20 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-26 08:58:46 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-26 12:57:21 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-26 13:00:21 --> 404 Page Not Found: Transaksi/%3C
ERROR - 2023-05-26 13:00:29 --> 404 Page Not Found: Transaksi/%3C
ERROR - 2023-05-26 13:03:17 --> Severity: error --> Exception: Call to undefined method CI_Session::destroy() C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 30
ERROR - 2023-05-26 13:04:19 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
