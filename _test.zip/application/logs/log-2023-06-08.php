<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-08 10:51:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\dermalicious_dev\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-06-08 10:51:28 --> Unable to connect to the database
ERROR - 2023-06-08 11:14:33 --> 404 Page Not Found: Dist/img
ERROR - 2023-06-08 11:17:33 --> 404 Page Not Found: Dist/img
ERROR - 2023-06-08 11:18:14 --> 404 Page Not Found: Assets/dist
ERROR - 2023-06-08 11:21:26 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-08 11:22:16 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-08 11:22:36 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-08 11:25:06 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-08 11:26:07 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-08 11:27:58 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-08 11:28:10 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-08 11:28:47 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-08 11:29:10 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-08 11:29:18 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-08 11:30:05 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-08 11:30:29 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-08 11:30:48 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-08 11:30:56 --> 404 Page Not Found: Asstes/dist
ERROR - 2023-06-08 11:34:53 --> 404 Page Not Found: Dist/img
ERROR - 2023-06-08 11:35:57 --> 404 Page Not Found: Main-packagehtml/index
ERROR - 2023-06-08 11:58:47 --> 404 Page Not Found: Dashboard/customer-transaction.html
ERROR - 2023-06-08 12:03:28 --> 404 Page Not Found: Dashboard/time-table.html
ERROR - 2023-06-08 12:35:42 --> 404 Page Not Found: master/User/index
ERROR - 2023-06-08 12:35:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Usermodel C:\xampp\htdocs\dermalicious_dev\system\core\Loader.php 349
ERROR - 2023-06-08 12:36:45 --> 404 Page Not Found: master/Insertuser/index
ERROR - 2023-06-08 12:47:50 --> Severity: Notice --> Undefined index: na_user C:\xampp\htdocs\dermalicious_dev\application\controllers\master\User.php 31
ERROR - 2023-06-08 14:17:19 --> 404 Page Not Found: User/inputuser
ERROR - 2023-06-08 14:29:34 --> Severity: error --> Exception: Call to a member function view() on null C:\xampp\htdocs\dermalicious_dev\application\controllers\Dashboard.php 15
ERROR - 2023-06-08 14:30:37 --> Severity: Notice --> Trying to get property 'create' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 33
ERROR - 2023-06-08 14:39:17 --> 404 Page Not Found: Transaksi/detailtransaksi1
ERROR - 2023-06-08 14:40:29 --> Query error: Table 'dermalicious_test.tbl_detail_transaksi' doesn't exist - Invalid query: SELECT *
FROM `tbl_detail_transaksi`
WHERE `id_transaksi` = '1'
ERROR - 2023-06-08 14:44:12 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 273
ERROR - 2023-06-08 14:44:12 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 324
ERROR - 2023-06-08 14:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 324
ERROR - 2023-06-08 14:51:56 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 259
ERROR - 2023-06-08 14:51:56 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 310
ERROR - 2023-06-08 14:51:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 310
ERROR - 2023-06-08 14:57:02 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 197
ERROR - 2023-06-08 14:57:02 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 248
ERROR - 2023-06-08 14:57:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 248
ERROR - 2023-06-08 14:57:30 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 175
ERROR - 2023-06-08 14:57:30 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 226
ERROR - 2023-06-08 14:57:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 226
ERROR - 2023-06-08 15:01:39 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 166
ERROR - 2023-06-08 15:01:39 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:01:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:02:44 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 166
ERROR - 2023-06-08 15:02:44 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:02:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:02:55 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 166
ERROR - 2023-06-08 15:02:55 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:02:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:03:05 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 166
ERROR - 2023-06-08 15:03:05 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:03:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:03:16 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 166
ERROR - 2023-06-08 15:03:16 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:03:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:03:22 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 166
ERROR - 2023-06-08 15:03:22 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:03:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:03:34 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 166
ERROR - 2023-06-08 15:03:34 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:03:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:03:37 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 166
ERROR - 2023-06-08 15:03:37 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:03:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:03:41 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 166
ERROR - 2023-06-08 15:03:41 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:03:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:03:46 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 166
ERROR - 2023-06-08 15:03:46 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:04:32 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 166
ERROR - 2023-06-08 15:04:32 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:06:03 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 166
ERROR - 2023-06-08 15:06:03 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:06:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:06:52 --> Severity: Notice --> Undefined variable: qty_total C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 158
ERROR - 2023-06-08 15:06:52 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 209
ERROR - 2023-06-08 15:06:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 209
ERROR - 2023-06-08 15:12:05 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:12:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:12:55 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:12:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 217
ERROR - 2023-06-08 15:20:34 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 214
ERROR - 2023-06-08 15:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 214
ERROR - 2023-06-08 15:20:48 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 214
ERROR - 2023-06-08 15:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 214
ERROR - 2023-06-08 15:25:22 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 214
ERROR - 2023-06-08 15:25:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 214
ERROR - 2023-06-08 15:25:37 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 214
ERROR - 2023-06-08 15:25:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 214
ERROR - 2023-06-08 15:26:25 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:26:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:26:49 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:26:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:27:34 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:27:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:27:40 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:27:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:28:03 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:28:13 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:28:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:28:20 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:28:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:49:31 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:49:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 220
ERROR - 2023-06-08 15:56:49 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 222
ERROR - 2023-06-08 15:56:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 222
ERROR - 2023-06-08 16:19:33 --> Severity: Notice --> Undefined index: id_detail_transaksi C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 224
ERROR - 2023-06-08 16:19:33 --> Severity: Notice --> Undefined index: qty_paket C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\detail_trans.php 228
ERROR - 2023-06-08 16:31:10 --> Severity: Notice --> Undefined index: tgl_trans C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 71
ERROR - 2023-06-08 16:31:10 --> Severity: Notice --> Undefined index: tgl_pembayaran C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 76
ERROR - 2023-06-08 16:31:10 --> Severity: Notice --> Undefined index: waktu_pembayaran C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 84
ERROR - 2023-06-08 16:32:02 --> 404 Page Not Found: Transaksi/verified1
ERROR - 2023-06-08 16:39:34 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 438
ERROR - 2023-06-08 16:42:41 --> Query error: Unknown column 'verified' in 'field list' - Invalid query: UPDATE tbl_transaksi SET status_veryfied = verified WHERE id_transaksi = 1
ERROR - 2023-06-08 16:43:51 --> Query error: Unknown column 'verified' in 'field list' - Invalid query: UPDATE tbl_transaksi SET status_veryfied = verified WHERE id_transaksi = 1
ERROR - 2023-06-08 16:49:44 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 442
ERROR - 2023-06-08 16:49:44 --> Severity: Notice --> Undefined variable: libur C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 456
ERROR - 2023-06-08 16:50:28 --> Severity: Notice --> Undefined variable: date_end C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 451
ERROR - 2023-06-08 17:19:38 --> 404 Page Not Found: Transaksi/1
