<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-31 09:56:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\dermalicious_dev\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-05-31 09:56:21 --> Unable to connect to the database
ERROR - 2023-05-31 10:02:40 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-31 10:07:55 --> Severity: Notice --> Trying to get property 'nama_klinik' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 65
ERROR - 2023-05-31 10:36:03 --> Severity: Notice --> Trying to get property 'nama_klinik' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 65
ERROR - 2023-05-31 10:36:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 65
ERROR - 2023-05-31 10:36:30 --> Severity: Notice --> Trying to get property 'nama_klinik' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 65
ERROR - 2023-05-31 10:36:36 --> Severity: Notice --> Trying to get property 'nama_klinik' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 59
ERROR - 2023-05-31 11:58:41 --> 404 Page Not Found: Transaksi/customer-detail.html
ERROR - 2023-05-31 16:30:03 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-31 16:30:12 --> Severity: Notice --> Undefined index: id_klinik C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 58
ERROR - 2023-05-31 16:30:12 --> Severity: Notice --> Trying to get property 'nama_klinik' of non-object C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 65
ERROR - 2023-05-31 16:34:29 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\create.php 79
ERROR - 2023-05-31 16:34:34 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\create.php 79
ERROR - 2023-05-31 16:34:54 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\create.php 79
ERROR - 2023-05-31 16:34:54 --> 404 Page Not Found: Transaksi/%3C
ERROR - 2023-05-31 16:35:04 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\create.php 79
ERROR - 2023-05-31 16:40:33 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\create.php 79
ERROR - 2023-05-31 16:40:35 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\create.php 79
ERROR - 2023-05-31 16:41:59 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\create.php 79
ERROR - 2023-05-31 16:42:00 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\create.php 79
ERROR - 2023-05-31 16:42:00 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\create.php 79
ERROR - 2023-05-31 16:42:01 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\create.php 79
ERROR - 2023-05-31 16:42:02 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\create.php 79
ERROR - 2023-05-31 16:42:18 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\create.php 79
ERROR - 2023-05-31 16:42:20 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\create.php 79
ERROR - 2023-05-31 16:42:20 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\dermalicious_dev\application\views\transaksi\create.php 79
ERROR - 2023-05-31 16:42:31 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-05-31 16:42:33 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
