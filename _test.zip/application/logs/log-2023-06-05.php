<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-05 09:33:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\dermalicious_dev\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-06-05 09:33:55 --> Unable to connect to the database
ERROR - 2023-06-05 11:16:42 --> Severity: error --> Exception: Call to undefined function base_ur() C:\xampp\htdocs\dermalicious_dev\application\views\js\script_transaksi_front.php 37
ERROR - 2023-06-05 14:56:32 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:56:32 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:56:32 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:56:32 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:56:32 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:56:32 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:56:32 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:56:32 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:56:32 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:56:32 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:56:32 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:56:32 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:56:32 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:56:32 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:57:51 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:57:51 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:57:51 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:57:51 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:57:51 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:57:51 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:57:51 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:57:51 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:57:51 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:57:51 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:57:51 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:57:51 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:57:51 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:57:51 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:58:52 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:58:52 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:58:52 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:58:52 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:58:52 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:58:52 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:58:52 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:58:52 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:58:52 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:58:52 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:58:52 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:58:52 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:58:52 --> Severity: Warning --> key() expects parameter 1 to be array, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 14:58:52 --> Severity: Notice --> String offset cast occurred C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 163
ERROR - 2023-06-05 15:05:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 162
ERROR - 2023-06-05 15:05:07 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 162
ERROR - 2023-06-05 15:05:18 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 162
ERROR - 2023-06-05 15:05:18 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 162
ERROR - 2023-06-05 15:05:34 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 162
ERROR - 2023-06-05 15:05:34 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 162
ERROR - 2023-06-05 16:17:03 --> Severity: error --> Exception: Call to undefined function year() C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 78
ERROR - 2023-06-05 16:17:15 --> Severity: error --> Exception: Call to undefined function year() C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 78
ERROR - 2023-06-05 16:17:24 --> Severity: error --> Exception: Call to undefined function YEAR() C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 78
ERROR - 2023-06-05 16:21:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''2023-05-06'' at line 3 - Invalid query: SELECT *
FROM `ms_holiday`
WHERE `date_holiday` = `>` '2023-05-06'
ERROR - 2023-06-05 16:30:02 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 76
ERROR - 2023-06-05 16:31:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 76
ERROR - 2023-06-05 16:32:06 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 76
ERROR - 2023-06-05 16:32:25 --> Severity: Warning --> date() expects parameter 1 to be string, object given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 76
ERROR - 2023-06-05 16:33:25 --> Severity: Warning --> date() expects parameter 2 to be int, string given C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 77
ERROR - 2023-06-05 16:37:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 77
ERROR - 2023-06-05 16:40:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 77
ERROR - 2023-06-05 16:41:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 77
ERROR - 2023-06-05 16:41:48 --> Severity: Notice --> Undefined variable: date_paid C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 79
ERROR - 2023-06-05 16:41:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`' at line 3 - Invalid query: SELECT *
FROM `ms_holiday`
WHERE `date_holiday` > `IS` `NULL`
ERROR - 2023-06-05 16:42:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 77
ERROR - 2023-06-05 16:50:18 --> Severity: Notice --> Undefined variable: start_date_paket C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 96
ERROR - 2023-06-05 18:03:22 --> Severity: Notice --> Undefined variable: start_date C:\xampp\htdocs\dermalicious_dev\application\controllers\Transaksi.php 310
